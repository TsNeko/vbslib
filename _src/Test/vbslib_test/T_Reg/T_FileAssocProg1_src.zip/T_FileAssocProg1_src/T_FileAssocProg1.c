#include  <windows.h> 
#include  <tchar.h>
#include  <stdio.h>


int  main( int argc, char* argv[] )
{
  printf( "argv[0] = \"%s\"\n", argv[0] );
  if ( argc >=2 )
    printf( "argv[1] = \"%s\"\n", argv[1] );

  _tprintf( _T("\n") );
  _tprintf( _T("Push close button...\n") );
  Sleep( INFINITE );
  return 0;
}

 
