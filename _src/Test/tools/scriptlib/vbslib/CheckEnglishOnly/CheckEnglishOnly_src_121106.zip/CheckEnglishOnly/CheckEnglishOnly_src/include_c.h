#include  <windows.h> 
#include  <tchar.h>
#include  "clib.h"
 
