This folder is not a project.
Assort_*.bat copies to module folders from a project.
