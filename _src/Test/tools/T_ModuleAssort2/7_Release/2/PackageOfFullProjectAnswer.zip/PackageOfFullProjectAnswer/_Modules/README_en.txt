This folder is not a project.
AssortAll.bat makes full module folders by copying files from project folders
in a parent folder.
