Test of that English file is newest
