﻿  ((( vbslib folder )))

'// vbslib - VBScript ShortHand Library  ver4.91  Oct.13, 2014
'// vbslib is provided under 3-clause BSD license.
'// Copyright (C) 2007-2014 Sofrware Design Gallery "Sage Plaisir 21" All Rights Reserved.

Sofrware Design Gallery "Sage Plaisir 21"  http://www.sage-p.com/
vbslib Home Page  http://www.sage-p.com/vbslib/vbslib.htm

------------------------------------
Copyright of bandled module

vbslib\zip folder is licensed on zlib license. Look at vbslib\zip\zip_readme.txt

------------------------------------

vbslib は、3-clause BSD ライセンスです。
vbslib\zip フォルダは、zlib ライセンスです。vbslib\zip\zip_readme.txt を見てください。

ソフトウェア デザイン館  Sage Plaisir 21  http://www.sage-p.com/
vbslib ホームページ  http://www.sage-p.com/vbslib/vbslib.htm

