﻿  ((( vbslib folder )))

'***********************************************************************
'* VBScript ShortHand Library (vbslib)
'* vbslib is provided under 3-clause BSD license.
'* Copyright (C) Sofrware Design Gallery "Sage Plaisir 21" All Rights Reserved.
'*
'* - $Version: vbslib 5.93 $
'* - $ModuleRevision: {vbslib}\Public\593 $
'* - $Date: 2017-03-20T20:00:00+09:00 $
'***********************************************************************

Sofrware Design Gallery "Sage Plaisir 21"  http://www.sage-p.com/
vbslib Home Page  http://www.sage-p.com/vbslib/vbslib.htm

------------------------------------
Copyright of bandled module

vbslib\zip folder is licensed on zlib license. Look at vbslib\zip\zip_readme.txt

------------------------------------

vbslib は、3-clause BSD ライセンスです。
vbslib\zip フォルダは、zlib ライセンスです。vbslib\zip\zip_readme.txt を見てください。

ソフトウェア デザイン館  Sage Plaisir 21  http://www.sage-p.com/
vbslib ホームページ  http://www.sage-p.com/vbslib/vbslib.htm

